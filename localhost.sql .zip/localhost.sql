-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 �?08 �?06 �?23:56
-- 服务器版本: 5.5.40
-- PHP 版本: 5.6.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `blog`
--
CREATE DATABASE `blog` DEFAULT CHARACTER SET gbk COLLATE gbk_chinese_ci;
USE `blog`;

-- --------------------------------------------------------

--
-- 表的结构 `blog_article`
--

CREATE TABLE IF NOT EXISTS `blog_article` (
  `art_id` int(11) NOT NULL AUTO_INCREMENT,
  `art_title` varchar(100) DEFAULT NULL COMMENT '文章标题',
  `art_tag` varchar(100) DEFAULT NULL COMMENT '关键词',
  `art_description` varchar(255) DEFAULT NULL COMMENT '描述',
  `art_thumb` varchar(255) DEFAULT NULL COMMENT '缩略图',
  `art_content` text COMMENT '文章内容',
  `art_time` int(11) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `art_editor` varchar(50) DEFAULT NULL COMMENT '作者',
  `art_view` int(11) NOT NULL DEFAULT '0' COMMENT '查看次数',
  `cate_id` int(11) NOT NULL DEFAULT '0' COMMENT '分类id',
  PRIMARY KEY (`art_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk COMMENT='文章' AUTO_INCREMENT=22 ;

--
-- 转存表中的数据 `blog_article`
--

INSERT INTO `blog_article` (`art_id`, `art_title`, `art_tag`, `art_description`, `art_thumb`, `art_content`, `art_time`, `art_editor`, `art_view`, `cate_id`) VALUES
(1, '人生犹如一首歌，音调高低起伏，旋律抑扬顿挫', '123', '12354463', 'uploads/20160806125106980.jpg', '<p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">在漆黑的夜晚，你要想到旭日东升的美好；在寒冷的冬季，你要想到千里冰封的壮丽；在汹涌的海边，你要想到乘风破浪的豪迈。人，决不能灰心于困难。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">我不是最美丽，但我可以最可爱；我不是最聪明，但我可以最勤奋；我不是最富有，但我可以最有情趣；我不是最健壮，但我可以最乐观。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">假如，你有一副动人的歌喉，但只会重复别人唱过的歌曲，我决不会把你赞许；假如，你有一副锐利的眼睛，但只会看到别人做事的是非，我决不会把你赞美；假如，你有一双健壮的脚板，但只会步踏别人走过的路，我决不会把你羡慕。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">如果说祖国是一艘远航的征船，我们就是那扬起的风帆；如果说青春是一盆不灭的炭火，我们就是那跳动的火焰。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">有理想的人说，生活像一杯蜂蜜，越品越甜；没有理想的人说，生活像一杯白开水，越喝越淡。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">以一种轻松平等的方式取代毕恭毕敬的心情，在呼朋引伴的称呼声中表现彼此友好的姿态，这不能不说是“朋友”一词的魅力所在。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">时间好比一部列车，它能承载我们驶向成功的未来；时间好比一位老人，它能帮助我们学到人生的真谛。人生犹如一次漫游，它能使你遇到许多新奇的事物；人生犹如一个顽童，它总是提出一些让你难以解答的问题。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">未经风雨交加的黑夜，哪能体会风和日丽的可爱；未经坎坷泥泞的艰难，哪能知道阳光大道的可贵，没有心血和汗水的付出，哪能尝到胜利成功的喜悦。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">其实人生也如四季：天真浪漫的童年是人生的春天，血气方刚的青年是人生的夏天，沉稳持重的中年是人生的秋天，蹒跚伛偻的老年是人生的冬天。但只要保持心灵的春天，生命将永远年轻。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">有勤，才有了孔子“韦编三绝”的佳话，也才有了孔子是世界文化史上大名人之一的美誉；有勤，才有了祖逖“闻鸡起舞”的美谈，也才有了他雄才大展北伐报国的伟业；有勤，才有了曹雪芹“披阅十载，增删五次”的壮举，也才有了世界文学史上的不朽名著《红楼梦》。</p><p><br/></p>', 1470190151, 'lisa', 81, 2),
(2, '六月花香 飘渺无迹', '123', '12354463', 'uploads/20160806125148432.jpg', '<p><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　结庐荆棘之间，身外红尘；纵倚萧墙之下，不过云烟。潇潇冷雨，几缕茶烟，凄凉满眼。沧海一声叹，云烟枕墨眠，曾有的忧患恩怨都随了流尘，曾有的苍凉繁华都成了笑谈。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　清晨雨打窗棂，敲醒一枕残梦。孤身懒起，对镜束装，不觉微恙。窗外紫燕，出入呢喃，云天外，世事邀风皆远走，叹前路，迷迷茫茫雨也愁。年年月月，走过了，心凉了，由得心愿的竟无一点。所有一切都幻化成空，不消挥手，便散的飘渺无迹。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　闲步野径间，扶风吹雨，思绪缠绵。古道垂柳小桥，亭外萧疏竹院，烟雨苔痕间，淡成一帧水墨画卷。此时可以低吟，可以高歌，盛久不衰的，也只有心碎肠断罢了。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　这么多年，开心的时光不多，犹如一片云朵，身不由己于时间的心湖漂泊。书箴后的那些笔记，时常勾勒未来的美丽，眼睛后的那些期望，却常常滴落伤痛的雨，淋湿了岁月，沾满了衣襟。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　走过生命的坎坷离合，不知不觉，岁月竟已如此苍老。流年曾给过我一个美丽而又绝然的梦，如此的我，还要等多久，才能看到另一个结果。距离有多远？咫尺抑或是天涯……</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　眉锁年岁，遥相望，终至成殇。时光若留，又何苦悲景伤情，人事若老，何不将我，也带走。</span></p>', 1470192636, 'lisa', 102, 2),
(16, 'efsdfvxz', '', '', 'uploads/20160804090711883.jpg', '<p>sdafvxcx</p>', 1470272834, '', 26, 2),
(17, 'yhgvnvfmhjy', '', '', 'uploads/20160804090749861.jpg', '<p>vtydjcvfghjyyukfvhmjhnk</p>', 1470272881, 'lisa', 0, 2),
(18, 'dsxcv', '', '', 'uploads/20160804102459982.jpg', '<p>fdsgx</p>', 1470277500, '', 1, 2),
(19, '谁笔下生花，唯美了曾经', '你好', '没什么', 'uploads/20160806125418105.jpg', '<p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">时光匆匆，转角处，往事成风。繁华落幕，惊觉处，物是人非。事过境迁，留下的只是那段被屋檐遮住的光阴；相思无处，目光倾城的诉说那段美丽的往事。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">　　</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">每个人都有过清澈的相逢，也有过美丽的错过。很多的时候一个无意的转身，便抖落了一地的故事。从花开到花落，从缘起到缘灭，谁是谁的风景；谁是谁等待入梦的人；又是谁装饰了美丽的梦？这一切都会泯灭在岁月的长河里，彼此留下无名的因果。<br/><br/>每个人的一生，都是为了过程而匆匆赶赴，在注定的因果里演绎着悲欢离合。似水流年，我们只要记住曾经回眸的微笑，忘记转身别离的伤怀；叶开叶落，只要彼此在时光里重叠过，就是最馨香的记忆。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">　　</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">我们常常会感叹！流年的风，将多少相遇吹落成一笺笺诗行，写就成一瞬间的沧海桑田。我们在云烟雨巷里行走，无法掌控邂逅与别离，只能在含苞待放时，放意绚烂。闻过了花香浓，不必伤感花期的短暂，人生注定有很多偶遇，遇见到谁都是一个美丽的意外。<br/><br/>有时只能珍惜着那些不离不弃的人，忘记那些有缘无分的情，那样才不会被红尘烟火所伤。虽然故事总是一见倾心的开始，人走茶凉的结局。还是庆幸，彼此的世界有来过的痕迹，不是所有的别离都会染上悲伤的色彩，凋零是为了更好的花期。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">　　</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">一程山水一年华，一世浮生一刹那。有时我们总是会问，岁月经得起多少等待？曾经策马天涯，并肩看天地浩大；曾经寒庐煮酒，巴山夜雨诉衷肠。可是，时间太瘦，指缝太宽，那些惊艳的画面总是不经意的从我们指缝间溜走。谁的背影辗转了谁的年华；谁将往事深深忆起？<br/><br/>也许是时光越老，人心越淡，走着走着就忘记了相遇的最初。暮然回首，沉淀的只是那段落花的记忆、交际时的点点滴滴。此时此刻，遗忘也许是最好的怀念。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">　　</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">红尘之上，秋水之下。有多少人说过:遇见你是最美丽的意外；又有多少人感叹过！如果回到从前，宁愿彼此擦肩而过不曾回头。世间所有的情缘只因一个相遇开始，关于那个遇见的故事，有人春暖花开，极致绽放；有人灯火阑珊，独自彷徨。无论是过客、或是归人都是生命中的缘分，只要在那因缘际会里，珍惜过、拥有过就是一种幸福。<br/><br/>生命的旅途中，我们不断的遇见一些人，也不停地和一些人说再见，多少念念不忘变成了悄无声息，多少相见恨晚变成了不如不见。时过境迁，当我们懂得如何去爱时，发现失去的是美好的纯真。也许人生总有些遗憾，不然繁花落尽，我们凭何缅怀？经年过后，这一种情怀，渐渐渗入我们的灵魂，绚烂了整整一个曾经。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">　　</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">一方素笺、一壶香茗、一砚清墨，在彼岸一头回味相遇时的最美。每个人都有过“人比黄花瘦”的悱恻，有过“惨绿愁红”的花事。红尘烟火里，谁绾一缕青丝，许三生不负；谁笔下生花，唯美了相识。如果说:三生石上种因果，一花一叶总关禅。那么，无论情深缘浅，过尽千帆，也不诉离别的惆怅，只言相聚的喜悦。若，彼此有缘，相信山水总会重逢。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">　　</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">时光匆匆，转角处，往事成风。繁华落幕，惊觉处，物是人非。事过境迁，留下的只是那段被屋檐遮住的光阴；相思无处，目光倾城的诉说那段美丽的往事。</p><p><br/></p>', 1470459286, 'lisa', 48, 3),
(3, '经典有内涵的美文美句：岁月，是一首诗', '123', '12354463', 'uploads/20160806125252246.jpg', '<p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">很多经典的美文美句，我们读过以后就遗忘了，当你想写点什么的时候，这些美文美句能丰富你文章的内涵，那就让我们一起来欣赏这些美文美句吧。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">1、 如果黑板就是浩淼的大海，那么，老师便是海上的水手。铃声响起那刻，你用教职工鞭作浆，划动那船只般泊在港口的课本 。课桌上，那难题堆放，犹如暗礁一样布列，你手势生动如一只飞翔的鸟，在讲台上挥一条优美弧线——船只穿过……天空飘不来一片云，犹如你亮堂堂的心，一派高远。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">2、 希望源于失望，奋起始于忧患，正如一位诗人所说：有饥饿感受的人一定消化好，有紧迫感受的人一定效率高，有危机感受的人一定进步快。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">3、 别在树下徘徊，别在雨中沉思，别在黑暗中落泪。向前看，不要回头，只要你勇于面对抬起头来，就会发现，分数的阴霾不过是短暂的雨季。向前看，还有一片明亮的天，不会使人感到彷徨。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">4、 柔和的阳光斜挂在苍松翠柏不凋的枝叶上，显得那么安静肃穆，绿色的草坪和白色的水泥道貌岸然上，脚步是那么轻起轻落，大家的心中却是那么的激动与思绪波涌。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">5、 生活的海洋并不像碧波涟漪的西子湖，随着时间的流动，它时而平静如镜，时而浪花飞溅，时而巨浪冲天……人们在经受大风大浪的考验之后，往往会变得更加坚强。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">6、 当你身临暖风拂面，鸟语花香，青山绿水，良田万顷的春景时，一定会陶醉其中；当你面对如金似银，硕果累累的金秋季节时，一定会欣喜不已。你可曾想过，那盎然的春色却是历经严寒洗礼后的英姿，那金秋的美景却是接受酷暑熔炼后的结晶。…………（何婷婷）</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">7、 倘若希望在金色的秋天收获果实，那么在寒意侵人的早春，就该卷起裤腿，去不懈地拓荒、播种、耕耘，直到收获的那一天。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">8、 生活是蜿蜒在山中的小径，坎坷不平，沟崖在侧。摔倒了，要哭就哭吧，怕什么，不心装模作样！这是直率，不是软弱，因为哭一场并不影响赶路，反而能增添一份小心。山花烂漫，景色宜人，如果陶醉了，想笑就笑吧，不心故作矜持！这是直率，不是骄傲，因为笑一次并不影响赶路，反而能增添一份信心。</p><p><br/></p>', 1470216510, 'lisa', 10, 3),
(20, '时光不旧，爱染流年', 'dsaref', 'aetrgf', 'uploads/20160806125540724.jpg', '<p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">七月的门楣，爬满郁郁青藤的繁华，檐角古老的风铃，摇曳着四季的明媚。落一笺小荷淡淡的香，蒹葭水岸，谁的情长落满沧桑，谁的孤单失去方向。那一棵在春天种下的朝颜，慎重的开满了我的清风篱笆墙。花香细细，容颜淡淡，像极了这雨后的心情。纤尘，不染。静里，生香。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">走过万水千山，我想，最幸福的遇见，便是，你一直在我看的见的地方，默然相爱，寂静喜欢吧。眼前，阳光下，那一架孤寂的秋千，荒芜着从前的笑语。我在风儿匆匆掠过眉心的时刻，轻轻落一笔珍重，岁月那么悠长。我以素心，虔诚清灯菩提下。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">生命，一直很安稳，就像此刻，所有的时光，忽然安静下来，却未曾染旧。那些开在阳光下的如莲往事，也被流年的风镌刻成一笺碎碎念，感动着，且令人神往。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">携手这一程水墨色的丹青，我们常常忘了还有明天。昨天留下的痕迹，如眼前我们一起走过的葱茏山水，有着无法复制的美。且让我，依着山水的蜿蜒，写一首无韵的小楷。多年以后，待你回头。这一笺苍绿的相遇，是甜到忧伤，是山水相依，是爱到一无所有！</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">隔着一川烟岚，我听到风里有谁轻轻的呼唤，路那么远，总担心一个人的漂泊，会有些孤单。我在你离去的那一个路口沏一壶新茶，等你再一次路过，等你留下来，慢慢陪我把这一盏茶喝到无味。直到青青子衿，直到青丝染霜。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">长长的岁月，我们淡淡过，平常的日子，有你，就好。愿我们的时光，山水绕肩，白云相伴，我在清风里的四季小院，酿一杯青梅酒。左手烟火，右手流年，安静陪你把光阴写老，把年华耗尽，醉一场琉璃的清欢，可好？</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">流年的印记，写满温良与慈悲。生命的罅隙里，明媚且渗透四季的芬芳。生命里的阳光很暖，随风而过的流年里，月如半弦。我在等你，等你，披一身月色缓缓归来。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">始终相信，生命的奇迹，就是让每一份爱都沾满阳光的温暖，渗透繁华过后的平淡。而你在这里，安静相伴，便是我最美的风景，无论春夏，不管秋冬。纵使，我们慢慢都有了沧桑，发丝有了白雪的痕迹，依然记得，不说离散。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">最是那一低头的温柔，让爱在眸里缱绻。我在落花堆积的萱纸上，留下素念生香，留下春风十里，留下柳笛声声，留下阳光明媚，留下桃花潭水。你若喜欢，就来我的诗里吧。或者，让我的诗住进你的心里。其实，你来，或不来；我去，或者不去，都一直在不成韵的诗行里，红袖添香，闲一段小桥流水的桑麻。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">时光不旧，爱染流年。有时候，站在多年前的篱笆院，看着开满蔷薇花的篱笆墙。忽然就会有一种说不出的惆怅，青梅已老，竹马已远。那些落满铜铃般的笑声，在七月暖暖的阳光下缭绕。是时光的无情，还是岁月的匆匆？仿佛一转眼，我们都成了时光里的过客。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">微风轻拂，花携着香。我追逐着多年前，那个一直追逐着的梦，没有了童真，我拥有了成熟的优雅。没有了童话，我知道了平淡不过最寻常。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">多年前的今天，是一首滴满清露的诗歌。以虔诚，以感恩，以多年前的初心，轻轻翻阅。依旧，那么美，那么真，那么妥帖的让一颗逐渐沧桑的心，皈依了最初的颜色。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">或许，有些迟到的遇见，注定是一场落花的忧伤。轻轻捧起曾经最繁华的绽放，转身许自己一份风轻云淡。不知，以后的以后，是否可以只与岁月说禅，只与流年缠绵。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">原谅时光吧，它淡去了从前，却留下一份永远。我微笑着用一朵花开的嫣然，逶迤生命中所有的美。纵使，流年耗尽，也会记得，爱的路上，我们曾经赠过彼此一场月圆的满。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">好想，在红尘中亲手为你种下一枚菩提。琉璃做心，阳光为念，执意一弦无暇的爱，让未来的每一个烟火里，都装满你的温良，与我青青的温柔。让爱，在生命的轮回里肆意沉沦，安静绽放。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">其实，最感动的，是在每个晨昏等你回家。一声念安，让眸里生出泪。今夜，打捞一缕月上柳梢的约，用思念，为你点燃一场篝火的狂欢。你在这里，我刚好路过，跳跃的火苗，是我们相依的温度。灼灼，却不会伤到彼此……</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">琉璃淡香，纵情文字的安寂。或许，终有一天，心中的那一片山河，会寂静到无声，鬓角的青丝渐渐泛上霜白。我依然会，用我一颗素净的心，念一个人，等一段情，择一古城。不说桑麻，不谈红尘，只让平淡的烟火沾染些许禅意，诗酒余生。</p><p><br/></p>', 1470459357, 'asd', 1, 12),
(21, '听一曲阑珊，凝一世冷香', 'utfjjh', 'adszvfc', 'uploads/20160806125643792.jpg', '<p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);"><strong style="padding: 0px; margin: 0px;">听一曲阑珊，凝一世冷香</strong></p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">剪一缕暖暖的冬日阳光，聆听一曲花开的声音，春荣秋谢，几多过往里，飘零了几许，不人可知。而今，将所有的哀伤轻轻碾成诗句，在来来回回，反反复复里，自我洗涤。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">一些轻音划过心中，泛起一季阑珊。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">一些清音零落心头，凝结成一世冷香。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">一些音乐如花绽放，将记忆流放远方。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">一些音符泌入心间，让灵魂魂归故乡。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">一杯清茶，一缕清香，一首轻音，一份情怀。在这孤冷的冬天，听一曲阑珊之音，凝一世冷香。让心随着音乐游走，让思绪静静飞扬。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">放一曲姬神的《一人静》，让小提琴的窃窃私语，钢琴的微微轻音，烫过心头，让飘渺的旋律如一缕清泉淌过心间，那乐声深沉中透着沉思，忧伤里伴着追忆，似千年的思绪，飘荡在记忆深处。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">生命原本就是孤独的，生命中路过的那些人，那些事都将会成为过往云烟，许多时候，我们依然孤孤单单，游游走走，心在紫陌红尘中游戈千年，流年如许，依然一人独静。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">一个人的夜，让心踏上孤独的旅程，让灵魂奔向遥远的旅途，于二胡的凝重，三味弦的孤独里，心开始蹒跚跋涉，穿过万水千山，穿过夜的迷茫，那飘渺的前方依然是一个未知的远方。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">风在轻轻的呼唤，心中一片苍茫，悠悠荡荡的灵魂迷失在风居住的街道，那音符凄冷迷离，如飘忽的记忆，悲伤的音符无法祭奠前生往事，浪漫的琴音交织着消逝的情怀。穿过风的记忆，漫步密林深处，悠远的笛声响起，夜莺开始深情歌唱，一声声凄婉，悲凉，穿过灵魂，将一抹疼痛吟落心头。穿过起起伏伏的山林，将满眼的泪花洒向夜空。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">我就像夜风中追梦人，在寻找着虚无的梦境，随着宁静的旋律飘起，一个梦在心中静静荡漾开，好似看到在迷雾深处。月光如水，将大地披上神秘的衣裳，风轻扬，有花香扑面而来。在那方神秘园里，萤火虫忽明忽暗，在四处飞舞，而我就静静地守候着，守候着那一方安宁。夜深沉的只留下呼吸与心跳，在音乐的馨香细语中，心婉若住进了神思者的家园，那幽远音乐如远古的召唤，轻轻柔柔，清清远远，划过心间让空虚的灵魂回家。将心灵流放那方令人神往的远方，陶笛的轻音响起，悠扬中涤静尘世的喧嚣，飘入心间，我已看到了故乡的原风景。那里远山如黛，饮烟袅袅，芳草萋萋，细水长流，鸟语花香。那是寻找已久的灵魂的居所;那是清风明月下的心灵净土;那是心灵旅途中一个归属地。历经千年，途径百世，心已回到久远的故土，留下一片静谧。</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">&nbsp;</p><p style="padding: 0px; margin-top: 0px; margin-bottom: 0px; font-family: 宋体; font-size: 14px; line-height: 25.2px; white-space: normal; background-color: rgb(243, 243, 243);">漫无边际的飘渺，心情，日渐烦躁，没有任何地方可以收藏自己的心情，我像一缕清风，穿行在迷离的夜色里。没有方向，没有尽头。只在音乐的海洋里，让心开出一朵莲的芬芳。随着凄美飘渺的旋律，在孤冷的心怀上，独守一抹孤芳，任思绪停停走走，任情怀清清幽幽。</p><p><br/></p>', 1470459423, 'wfds', 3, 3),
(12, '在流年生活里，轻度时光', '123', '12354463', '', '<p>&nbsp; <span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">一个人映现一个世界；一颗心搏动一缕思绪。喜怒哀乐互相交织，悲欢离合彼此参合，阴晴阳缺轮流交替，人生都曾经一一饱尝过。有时，寂寞袭上心头，一时间惶惶不安，无所事事；有时，也许空虚侵入生活，百无聊奈，不知如何打发时光，怎度流年？有时，也许孤独叩击心门，心灵渴望一股真情，盼望与人相交，可以倾诉心事，共度阴暗时光。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　在时光里，一杯茶，一种人生。烧点开水，在悠闲里，你可以静观水气升腾，悠然自在，静听水声呢喃，响在耳边。一泡茶，一种观点，会苦上一阵子，但也会清香四溢，滞留齿间。品茶，浅尝人生，心静似止水。打发时间里，你何妨细细品尝温情的茶水，看水冒出气泡，观茶粒松散开来，也可详赏茶叶在翻腾，染绿清水。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　一杯甘浓的茶水进入口里，润滑有余香，舌底生津，心情舒畅。这时，一个人虽然孤身只影，却因为与茶相伴，一种安心从心底升起，静美时光持续不慌张，恒久不心乱。人生安详且时光深浓，光阴生动有力，日子生机勃勃。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　如果有几个人，相聚一起，可以闲聊家长里短，趣谈家事、国事和天下事，畅想不同的人生、异同的追求和坚持的理想，可以讲逆境之人成才不易，也可以论信念支撑坚持。你们可以谈论“勤劳一日，可得一夜安眠；勤劳一生，可得幸福长眠。”几个人可以说艰难困苦铸就人才，不留退路才有出路，议论诸子百家，纵横天下焦点……人生不但抛走无奈而显得充实，生活撇开烦躁而变得宁静。</span></p>', 1470216886, 'lisa', 1, 3),
(15, 'efvdgtfh', '', '', 'uploads/20160803225904807.jpg', '<p>dwsfsdgvfvbcbgfxsdzS</p>', 1470236360, 'chenmeng', 0, 2),
(14, 'lisa', 'rewqrdswe', '', 'uploads/20160803223640651.jpg', '<p>redfcxdasdc</p>', 1470232471, 'fesd', 0, 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_category`
--

CREATE TABLE IF NOT EXISTS `blog_category` (
  `cate_id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(50) NOT NULL COMMENT '分类名称',
  `cate_title` varchar(255) NOT NULL COMMENT '分类说明',
  `cate_keywords` varchar(255) NOT NULL COMMENT '关键词',
  `cate_description` varchar(255) NOT NULL COMMENT '描述',
  `cate_view` int(10) NOT NULL DEFAULT '0' COMMENT '查看次数',
  `cate_order` tinyint(255) NOT NULL DEFAULT '0' COMMENT '排序',
  `cate_pid` int(11) NOT NULL DEFAULT '0' COMMENT '父级id',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- 转存表中的数据 `blog_category`
--

INSERT INTO `blog_category` (`cate_id`, `cate_name`, `cate_title`, `cate_keywords`, `cate_description`, `cate_view`, `cate_order`, `cate_pid`) VALUES
(2, '体育', '热爱体育事业，发扬体育精神', '', '54654132', 0, 0, 0),
(3, '娱乐', '人人都有自己的娱乐圈', '', '46852316947', 0, 0, 0),
(26, '新闻', '随便吧', '最新新闻', '4865413612', 0, 0, 0),
(5, '热点新闻', '最热新闻，最好', '', '', 0, 0, 26),
(6, '军事新闻', '我没词了', '', '', 0, 12, 26),
(7, '体育彩票', '中奖率好高呀', '', '652316541', 0, 0, 2),
(8, '体育赛事', '我们提供最新的体育赛事活动', '', '154321146354', 0, 0, 2),
(9, '音乐娱乐', '我喜欢听音乐', '', '', 0, 0, 3),
(17, 'dwsae', '', '', '', 0, 0, 16),
(12, '体育事业', '我是好人', '啊啊啊', 'cfxz', 0, 32, 2),
(19, 'qwd121323', 'sdxfdcx', '', '', 0, 0, 18);

-- --------------------------------------------------------

--
-- 表的结构 `blog_config`
--

CREATE TABLE IF NOT EXISTS `blog_config` (
  `conf_id` int(11) NOT NULL AUTO_INCREMENT,
  `conf_title` varchar(50) DEFAULT NULL COMMENT '标题',
  `conf_name` varchar(50) DEFAULT NULL COMMENT '变量名',
  `conf_content` text COMMENT '变量值',
  `conf_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `conf_tips` varchar(255) DEFAULT NULL COMMENT '描述',
  `field_type` varchar(50) DEFAULT NULL COMMENT '字段类型',
  `field_value` varchar(255) DEFAULT NULL COMMENT '字段值',
  PRIMARY KEY (`conf_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='网站配置' AUTO_INCREMENT=10 ;

--
-- 转存表中的数据 `blog_config`
--

INSERT INTO `blog_config` (`conf_id`, `conf_title`, `conf_name`, `conf_content`, `conf_order`, `conf_tips`, `field_type`, `field_value`) VALUES
(1, '网站标题', 'web_title', 'blog系统', 1, '网站大众化标题1', 'input', ''),
(2, '统计代码', 'web_count', 'http://www.houdunwang.com', 3, '网站访问情况统计', 'input', ''),
(4, '网站状态', 'web_status', ' 0 ', 2, '网站开启状态', 'radio', '1 | 开启, 0 | 关闭'),
(7, '关键词', 'keywords', 'php基础课程，php视频', 5, '', 'input', ''),
(6, '辅助标题', 'seo_title', '来自后盾网', 4, '对网站名称的补充', 'input', ''),
(8, '描述', 'description', '后盾网的php视频', 6, '', 'textarea', ''),
(9, '版权信息', 'copyright', 'Design by me', 7, '', 'textarea', '');

-- --------------------------------------------------------

--
-- 表的结构 `blog_links`
--

CREATE TABLE IF NOT EXISTS `blog_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `link_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '链接',
  `link_order` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `blog_links`
--

INSERT INTO `blog_links` (`link_id`, `link_name`, `link_title`, `link_url`, `link_order`) VALUES
(1, '郑州师范学院', '国内最好的学', 'http://www.baidu.com', 1),
(2, '没啥说了', 'title是啥', 'http://www.baidu.com', 2),
(3, '极客学院', 'lisa真棒', 'http://www.baidu.com', 4);

-- --------------------------------------------------------

--
-- 表的结构 `blog_migrations`
--

CREATE TABLE IF NOT EXISTS `blog_migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `blog_migrations`
--

INSERT INTO `blog_migrations` (`migration`, `batch`) VALUES
('2016_08_03_231522_create_links_table', 1);

-- --------------------------------------------------------

--
-- 表的结构 `blog_navs`
--

CREATE TABLE IF NOT EXISTS `blog_navs` (
  `nav_id` int(11) NOT NULL AUTO_INCREMENT,
  `nav_name` varchar(50) DEFAULT NULL COMMENT '名称',
  `nav_alias` varchar(50) DEFAULT NULL COMMENT '别名',
  `nav_url` varchar(255) DEFAULT NULL,
  `nav_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`nav_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='导航栏' AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `blog_navs`
--

INSERT INTO `blog_navs` (`nav_id`, `nav_name`, `nav_alias`, `nav_url`, `nav_order`) VALUES
(2, '关于我', 'About', 'http://', 2),
(1, '首页', 'Protal', 'http://127.0.0.1/blog/', 1),
(3, '慢生活', 'Life', 'http://www.baidu.com', 3),
(4, '碎言碎语', 'Doing', 'http://www.baidu.com', 4),
(5, '模板分享', 'Share', 'http://www.baidu.com', 5),
(6, '学无止境', 'Learn', 'http://www.baidu.com', 6),
(7, '留言板', 'Guestbook', 'http://127.0.0.1/blog/', 7);

-- --------------------------------------------------------

--
-- 表的结构 `blog_user`
--

CREATE TABLE IF NOT EXISTS `blog_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL COMMENT '//用户名',
  `user_pass` varchar(255) DEFAULT NULL COMMENT '//密码',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `blog_user`
--

INSERT INTO `blog_user` (`user_id`, `user_name`, `user_pass`) VALUES
(1, 'lisa', 'eyJpdiI6IjNYcWRrUE5ST0xCa1pwTm1mNjNtWkE9PSIsInZhbHVlIjoiZnRcL28wTzFSczhnOW42cksxZXpxbXc9PSIsIm1hYyI6ImYwNzA5M2IwZTk3Nzc4MzE0ZThiNTcyY2Y0MmQwZmUxOTdjNmNmNjk3NGVmNTViYzg3Y2RmN2E5MzkzODNlY2IifQ==');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
